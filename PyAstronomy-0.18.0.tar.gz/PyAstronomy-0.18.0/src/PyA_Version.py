
def PyA_Version():
    return "0.18.0"
