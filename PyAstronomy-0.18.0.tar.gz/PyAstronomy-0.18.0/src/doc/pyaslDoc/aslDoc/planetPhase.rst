Phases a planet
================

Phase function for the Lambert sphere
-------------------------------------

.. currentModule:: PyAstronomy.pyasl

.. autofunction:: lambertPhaseFunction