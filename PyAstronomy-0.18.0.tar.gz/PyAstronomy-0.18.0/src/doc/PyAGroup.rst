Members of the PyA group
============================

PyAstronomy is a collaborative effort started by SC and SS during
a (really!) bad-weather observing run high-up on island X.    

 * Stefan Czesla (SC)
 * Sebastian Schröter (SS)

 
**Valuable and highly appreciated contributions** to the project have meanwhile been provided
by the following authors:
 
 * Christian P. Schneider
 * Klaus F. Huber
 * Fabian Pfeifer
 * Daniel Thaagaard Andreasen
 * Mathias Zechmeister (GLS)
 