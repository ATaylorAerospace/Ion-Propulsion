The PyA File System
====================

Well, "file system" is not really true. It is only a tool to manage
access to PyA's data directory

.. currentmodule:: PyAstronomy.pyaC.pyaPermanent
.. autoclass:: PyAFS
   :members: