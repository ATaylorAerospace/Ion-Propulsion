Conversions and calculations
================================

.. currentmodule:: PyAstronomy.pyaC

Convert degree into rad and vice versa
---------------------------------------

.. autofunction:: degtorad
.. autofunction:: radtodeg

Compute ratio of factorials
----------------------------

.. autofunction:: farat
