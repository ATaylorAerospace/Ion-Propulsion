Contact us
===================

We appreciate your opinion.

If you intend to send us any comments, remarks, bug reports, wishes,
or coarse insults, you can do so using PyAstronomy's project page on

  `github <https://github.com/sczesla/PyAstronomy>`_

or simply send us an e-mail to 

  *stefan.czesla@hs.uni-hamburg.de*

In any case,
we will try our best to answer appropriately.